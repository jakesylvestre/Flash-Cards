dimensions(4,4)
wall((1,0),(1,2))
wall((1,2),(2,2))
wall((1,3),(3,3))
wall((3,3),(3,0))
wall((3,1),(2,1))

initialRobotLoc(1, 3.5)
