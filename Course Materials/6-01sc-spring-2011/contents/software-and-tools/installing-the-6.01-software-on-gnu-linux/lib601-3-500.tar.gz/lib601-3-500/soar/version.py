#!/usr/bin/python
################################soar/version.py#################################
# soar3.500
#  / version.py
# (C) 2006-2008 Michael Haimes
#
# Protected by the GPL
#
#
# ...
# Go ahead, try and sue me
################################################################################

####################################Imports#####################################
BIG_VERSION = 3
REVISION = 500
def format_version():  return "%d-%s" % (BIG_VERSION, REVISION)
