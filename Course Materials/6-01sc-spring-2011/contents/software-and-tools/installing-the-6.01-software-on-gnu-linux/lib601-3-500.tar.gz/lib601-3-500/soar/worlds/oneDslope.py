dimensions(8,2)
wall((0,1.5),(8,2.0))
initialRobotLoc(1, 1.0)
