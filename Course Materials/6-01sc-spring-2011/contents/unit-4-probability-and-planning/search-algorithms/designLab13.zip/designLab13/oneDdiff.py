dimensions(8,2)

wall((0, 2), (8, 2))

wall((1, 1.5),(1.5, 1.5))

wall((2, 1.6),(2.8, 1.6))

wall((3.1, 1.4),(3.5, 1.4))

initialRobotLoc(1.0, 1.0)
