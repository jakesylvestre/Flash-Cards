import lib601.le as le
import lib601.circ as circ

ce = le.EquationSet()
# Enter your equations here
print ce.solve()

ce1 = circ.Circuit([
    # Enter your circuit components here
    ])
print ce1.solve('e0')
